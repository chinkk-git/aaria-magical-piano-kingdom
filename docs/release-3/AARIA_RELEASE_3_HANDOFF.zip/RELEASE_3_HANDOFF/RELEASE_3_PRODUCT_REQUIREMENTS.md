# Release 3 product requirements

## Purpose
Aaria uses a tablet beside her own physical keyboard and learns independently with a deterministic, friendly coach. Manual teaching is the complete default path. On-screen piano, microphone listening, and MIDI are optional user-selected modes.

## Must-have behavior
1. Academy home is reachable without replacing current Piano Hero default. All 36 classes (12 each Basic/Medium/Advanced) are directly selectable; level labels never gate access.
2. Each class has Guided and Practice by Myself flows; default plan totals 15 minutes (2 warm-up, 4 explain/demo, 4 guided, 3 application, 2 reflection), with repeat, pause/resume, skip, slow, and short-session controls.
3. Manual physical-keyboard mode needs no permission, connection, setup, score, or accuracy claim. Demonstrations are generated from the exact lesson note-event sequence.
4. Optional MIDI and microphone workstreams are required for Release 3; child activation is optional. Unsupported/rejected/unreliable input returns to manual mode without blocking learning.
5. Optional evaluation is separate from enrollment and navigation. Cradle Song is not used as a reference until actual library data and provenance are inspected. No invented reference notes.
6. Progress is local-first and distinguishes completion, self-report, and measured observation. Never erase existing songs, favorites, OMR cache, or settings.
7. EN-GB and PT-BR have equivalent class content and key controls.
8. No paid services, cloud accounts, ads, tracking, external AI APIs, or mandatory model startup.

## User paths
- Home → Browse all → any class → Guided / Independent → demo → practice on selected input → reflect → locally save checkpoint.
- Home → Optional skill evaluation → choose verified song/fixture or self-reflection → transparent result → suggested classes, all navigable.
- Lesson → choose mode any time → capability check/permission only after opt-in → test signal/device → proceed or one-tap manual fallback.

## Non-functional
- Phone, iPad portrait/landscape and desktop; large distance-readable note labels, adjustable text, reduced motion, captions, high contrast, 44px minimum controls.
- Offline class browsing/playback once lesson shell/content cached; no OMR prerequisite. PWA update assets use versioned URLs; preserve all user records during update.
- No manipulative streaks, public rankings, punitive grading, or child account collection.

## Out of scope for this package
Final owner-approved artwork/layout, production integration, real-device compatibility claims, app deployment, verified Cradle Song assessment, and claims of reliable polyphonic mic grading.
