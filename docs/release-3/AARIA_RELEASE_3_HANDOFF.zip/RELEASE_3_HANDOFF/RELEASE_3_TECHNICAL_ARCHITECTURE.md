# Release 3 technical architecture

## Repository baseline (evidence and limits)
Observed repository `chinkk-git/aaria-magical-piano-kingdom`, default branch `main`, latest commit visible during audit `c1d88ceb60ec05e78976ab9082dbddd794661344` (PR #24). Control Tower #11 states Pages deploy run 44371936119 for the prior R1 baseline; this does not prove current deployment of PR #24. Issue #25 is open and worker comments show `fix/issue-25-add-new-song-piano-hero` based on PR #24 being actively edited; no PR yet at observation. Re-check before branch creation.

Inspected `index.html`, `sw.js`, `my-songs.js`, `song-import.js`, Issue #11, and Issue #25. The current app is a compact, inline-script PWA. `sw.js` cache constant observed as `aaria-piano-v1.19.0`, with OMR assets currently in the shell precache at that snapshot. `my-songs.js` declares localStorage key `aaria-piano-custom-songs-v1`, favorites `aaria-piano-favorites-v1`, recents `aaria-piano-recent-v1`, and IndexedDB `aaria-piano-library` version 2. Issue #25 owns PWA/update, Hero, Add New Song and OMR startup edits; treat these as volatile. `index.html` begins with visible diagnostic text before doctype according to Issue #25 diagnosis. Do not edit those files in parallel.

`README.md` and `piano.js` were not found at repository root (404). App source was not fully downloaded as a local clone; specific integration contracts beyond observed sources remain to be confirmed in current branch.

## Proposed module graph
`academy-route` → `academy-shell` → `curriculum-loader` → `lesson-engine` → `coach-controller` → `demonstration-player` and `input-adapters` → `event-normalizer` → `feedback-engine` → `progress-repository`. `locale` and `a11y` are cross-cutting services. Keep modules namespaced in `academy/` until hotfix merges.

## Interfaces
- `CurriculumRepository.list({level?,locale}) -> LessonSummary[]`; `get(id) -> LessonDefinition`; validates schema and stable IDs before render.
- `LessonEngine.start(id,mode)`, `pause()`, `resume()`, `seekStage(stageId)`, `completeExercise(id,source)`, `snapshot()`; state transitions are deterministic and resumable.
- `DemonstrationPlayer.play(events,{tempo,fromBeat,toBeat})`, `stop()`, `setRate(0.5..1.0)`; use existing sound engine only behind a thin adapter after API inspection. Never make lesson audio timestamps diverge from the displayed events.
- `InputAdapter.capabilities()`, `connect()`, `subscribe(listener)`, `disconnect()`; adapters are manual, onscreen, MIDI, microphone. Request permissions only after explicit selection.
- `FeedbackEngine.compare(reference,observed,calibration)` returns matched/missed/extra/uncertain events plus separately calculated pitch and timing aggregates. Manual mode returns no observed score.
- `ProgressRepository.saveCheckpoint`, `recordCompletion`, `recordObservation`, `export/import`; separate academy namespace/schema; migration is additive, versioned, idempotent and rollback-safe.

## Data flow
Lesson event sequence is immutable reference. Audio/visual cursor reads it; input adapter emits normalized observations; matcher applies documented window/confidence gates; feedback UI receives a typed result; progress writer records only the minimum local summary. Raw microphone audio is never persisted or transmitted.

## Integration sequence
1. Rebase planning branch on latest main after Issue #25 resolves; inspect changed files and contracts again.
2. Add namespaced modules and tests without editing existing app shell or service worker.
3. Integrate route via one minimal entry point only after hotfix PR is merged/owner-approved; avoid body/layout takeover.
4. Add lesson assets to cache with versioned URLs and small payloads; no model files in core Academy shell.
5. Test preservation from production-like profile before/after updates.

## Error handling
All adapter failures return a typed capability state; catch permission, device, audio-context, decoding, offline, storage quota, schema and update failures. Preserve lesson state; offer manual mode; do not block class access.
