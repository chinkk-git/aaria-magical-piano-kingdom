# Dependency-ordered Release 3 backlog

Every task is a separate reviewable PR or small PR group. Start only after checking Issue #25 merge/head state. Keep all tasks off `main`; no merge/deploy without owner approval.

| ID | Scope / dependencies | Definition of done |
|---|---|---|
| R3-01 Baseline reconfirmation | after #25 state stable | record main SHA, live Pages build, current DOM/storage/SW/audio API, Cradle actual score if present; map exact new files; no code changes to hotfix files |
| R3-02 Module shell & route | R3-01 | namespaced Academy entry, behind feature flag/route, hero default preserved, accessible empty/loading/error states, visual placeholders |
| R3-03 Curriculum loader | R3-02 | schema validator loads 36 files; no gated prerequisites; exact original events feed demo |
| R3-04 Lesson engine & manual mode | R3-02/03 | guided and independent state machine, 15-min adjustable plan, pause/skip/repeat/slow/resume, no score in manual |
| R3-05 Demonstration adapter | R3-04 + confirmed sound API | event/visual cursor synchrony and rate control; no changes to Hero/Classic playback without regression |
| R3-06 On-screen adapter | R3-04 | reuses existing note events; Hero and Classic behavior preserved |
| R3-07 MIDI adapter | event contract | permission-gated Web MIDI, discovery, decode, timing, disconnect/reconnect, tests; capability matrix truthfully labeled |
| R3-08 Microphone adapter | event contract | consent, local monophonic detector, cleanup, confidence/latency gates, fixtures plus recorded device suite; no polyphonic claim |
| R3-09 Feedback/evaluation | R3-03/05/07/08 | confidence-aware matching, self-report fallback, optional Cradle only when repository score verified |
| R3-10 Local progress | R3-01 storage audit, then R3-04 | additive own DB, schema migration/export/quota handling; existing song DB and keys unchanged |
| R3-11 Localization/a11y | parallel after R3-02 | EN-GB/PT-BR complete parity, captions, focus/reduced motion/text scale/contrast checked |
| R3-12 Workstream B integration | visual package available | retain component contracts; layouts integrated without behavior changes; no unapproved character treated as final |
| R3-13 Offline/PWA | after #25 merge + R3 modules | only small/versioned lesson shell in cache; no mandatory OMR; update test preserves library and OMR cache |
| R3-14 End-to-end and release review | all above | 36 class test, device evidence, accessibility, data preservation, documented known limits, worker checklist; owner review |

Worker must use files/contracts as proposed until repo inspection verifies integration points. Report actual paths and evidence. Do not independently change scope, close Issue #25, merge, deploy, or clear site data.
