# Test strategy and acceptance evidence

## Package tests
- Validate 36 unique IDs and exactly 12 per level; no prerequisites/locks; bilingual required fields; schedule sums to 15; event onset nondecreasing and positive lengths; pitch labels agree with MIDI; exercise ranges valid; input modes list all four.
- Schema validation and fixture round-trip.

## Unit tests for implementation
- Lesson state machine: skip/pause/reload/resume/independent mode; never gates.
- Timeline/audio/visual event alignment; speed changes preserve relative rhythm.
- MIDI decoder: channel/note parsing, velocity-zero note-off, pairing, disconnect, duplicate messages, CC64 only when supported.
- Microphone: known sine tones across A4 and octave boundaries, harmonic ambiguity, noise floor, clipped signal, silence, onset and latency; report false positives/negatives and latency distributions. Disable scoring if thresholds fail.
- Matcher: one-to-one matching, tolerance boundary, uncertain observations excluded, no score for manual mode.
- Persistence: reload, quota error, migration, corrupt record, duplicate save, export/import; assert existing song keys/DB untouched.

## Integration/device matrix
Run secure-context browser tests on desktop Chrome/Edge/Safari; actual iPadOS Safari/PWA and Android Chrome/PWA; portrait/landscape; offline after shell cache; deny/revoke permission; disconnect/reconnect; background/screen lock; update from previous SW while preserving songs/favorites/OMR cache. Distinguish simulated API tests from hardware tests.

## Acceptance gates
1. All 36 lessons open directly; optional evaluation never blocks.
2. Physical/manual complete path works with no permission/connectivity and never claims to listen.
3. Both mic and MIDI adapters exist; capability fallbacks never block access.
4. Only calibrated/quality-qualified observations create scores; note and timing metrics are separate.
5. Progress survives reload/update; song library and OMR data stay unchanged.
6. EN-GB/PT-BR parity; keyboard and screen-reader navigation; reduced motion; clear focus.
7. Actual responsive screenshot review after Workstream B integration; screenshots label viewport, browser, commit and whether fixtures are used.

No app/device test has been run by this planning package.
