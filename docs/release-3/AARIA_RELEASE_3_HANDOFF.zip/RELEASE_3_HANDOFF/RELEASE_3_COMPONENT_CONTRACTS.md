# Component and API contracts

## Module tree (proposed; do not claim these exist)
`academy/index.js`, `academy/catalogue.js`, `academy/lesson-engine.js`, `academy/coach-controller.js`, `academy/demonstration-player.js`, `academy/inputs/{manual,onscreen,midi,microphone}.js`, `academy/event-normalizer.js`, `academy/feedback.js`, `academy/progress-repository.js`, `academy/locales/{en-GB,pt-BR}.json`, `academy/styles/tokens.css`.

## Contracts
- `LessonRepository.get(id, locale)` validates JSON; rejects duplicate/malformed IDs; missing locale falls to English with explicit language marker.
- `InputAdapter` methods: `capabilities(): Capability`, `connect(options): Promise<CapabilityState>`, `subscribe(fn): unsubscribe`, `stop(): Promise<void>`. `manual` always available.
- `LessonEngine` is the only owner of stage transitions; UI sends commands, never changes stored state directly.
- `CoachView` accepts `{state, messageKey, params, caption, reducedMotion}` and renders placeholder `coach-slot`; final avatar/layout is external design input.
- `EventTimeline` accepts the exact lesson event array and emits `eventstart/eventend` with eventId and monotonic timestamp; visuals consume the same event IDs.
- `ProgressRepository` exposes `loadProfile/saveProfile/saveCheckpoint/recordCompletion/recordObservation/listRecords/export/import`; adapter errors are typed.

## Visual placeholder and token contract
Use tokens only: `--academy-space-*`, `--academy-color-night`, `--academy-color-plum`, `--academy-color-gold`, `--academy-text-primary`, `--academy-focus-ring`, `--academy-target-min:44px`. Slots: `coach-slot`, `lesson-header-slot`, `score-or-note-display-slot`, `keyboard-range-slot`, `lesson-controls-slot`, `feedback-slot`. Workstream B may replace composition/art but must retain semantic labels, IDs, input contracts, safe areas, focus order and data states. No final artwork/approval is implied.

## Events and errors
DOM events are namespaced `academy:modechange`, `academy:stagechange`, `academy:inputstate`, `academy:observation`, `academy:storageerror`. Errors carry stable `code`, localized `messageKey`, recoverability, and recommended action; do not include raw audio or child-identifying data.
