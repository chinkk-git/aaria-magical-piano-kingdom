# Optional microphone and MIDI implementation specification

Both adapters are mandatory Release 3 engineering deliverables. Aaria never has to activate them. Current compatibility is unverified in this planning package; do not claim real-device support before the listed tests.

## Shared event contract
`ObservedNote {source, midiNote, onsetMs, offsetMs?, velocity?, confidence?, channel?, receivedAtMs, latencyEstimateMs?, calibrationId?, deviceId?}`. Keep observed event distinct from immutable expected lesson event. Normalize timestamps to monotonic `performance.now()` clock where possible; MIDI timestamp origin must be converted/calibrated. A note-on with velocity zero is note-off.

## MIDI adapter
1. Feature detect `navigator.requestMIDIAccess`; user action only. State values: unsupported, permission-needed, connecting, connected, disconnected, error.
2. Enumerate inputs after permission; allow named selection without retaining device identity longer than locally needed. Subscribe to `midimessage`, parse status/channel/note/velocity; pair note-on/off, handle 0-velocity note-off, sustain CC64 only if test supports it.
3. Observe `statechange`; detach listeners and clear active notes on disconnect/stop; provide reconnect and manual fallback. Do not assume iPadOS Safari support. Browser API availability is not proof of keyboard/device access.

## Microphone adapter
1. On explicit activation request `getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}})` with fallback constraints if rejected; show visible listening and stop. Never persist raw audio.
2. Use AudioContext + analyser/AudioWorklet where supported; inspect sample rate, clipping/noise floor and permission; stop tracks, close context, remove worklet on exit/background/revoke.
3. Prototype scope: monophonic notes only. Implement FFT/autocorrelation pitch candidate; map frequency to MIDI `round(69+12*log2(f/440))`; require stable voiced frames, minimum signal/noise ratio, confidence ≥0.90 over consecutive frames and a locally measured device latency calibration. Detect onset by energy change; suppress octave ambiguity unless confidence resolves it.
4. Disable automatic grading for chords, noisy/ambiguous notes, overlap, low confidence, unknown instrument latency, or unsupported capture. Give manual fallback. Do not claim robust polyphony.

## Matcher and scores
Match events one-to-one within calibrated onset window ±120 ms initially (configurable only after measurement); note pitch must match exact MIDI; tolerance window validated per device. Report `pitchMatchRate` and `timingMatchRate` only when at least 5 eligible expected events and ≥80% observed confidence. Formula = matched eligible events / eligible expected events; unmatched events count as misses only if input stayed healthy and session was calibrated. Otherwise result is `insufficient-evidence`, not 0%. Keep completion independent.

## Browser/device evidence matrix
| Environment | API claim | Planned evidence required |
|---|---|---|
| iPadOS Safari/PWA | microphone API typically available subject to secure context/permission; Web MIDI availability must be checked at runtime; do not assume support | real iPad microphone, denial/revoke/background; MIDI capability detection and keyboard test if available |
| Android Chrome/PWA | Web MIDI/audio APIs are browser/device/permission dependent | actual phone/tablet + physical MIDI keyboard for MIDI; mic tone/noise/latency suite |
| Desktop Chrome/Edge | APIs may be exposed in secure contexts; device/OS permissions still apply | synthetic MIDI decoder, real keyboard, loopback tones, disconnect, screen/background |
| Desktop Safari | MIDI support cannot be generalized; runtime detect | separate versioned browser capability run; mic and MIDI device tests |

Table describes tests to perform, not completed compatibility claims.
