# Localization specification EN-GB / PT-BR

Lessons include `title.en-GB`, `title.pt-BR`, `objective` in both locales and dialogue per lesson in both locales. Use locale tags exactly. UI keys should be shared in two JSON dictionaries, never concatenated into English phrases.

Required shared keys include: `academy.home`, `academy.allClasses`, `academy.level.basic`, `academy.level.medium`, `academy.level.advanced`, `lesson.guided`, `lesson.independent`, `lesson.listen`, `lesson.tryPhysical`, `lesson.repeat`, `lesson.slow`, `lesson.pause`, `lesson.resume`, `lesson.previous`, `lesson.next`, `lesson.finish`, `input.manual`, `input.onscreen`, `input.microphone`, `input.midi`, `input.unsupported`, `input.permissionNeeded`, `input.disconnected`, `input.listening`, `input.connected`, `input.continueManual`, `evaluation.optional`, `progress.selfReported`, `progress.measured`, `feedback.uncertain`.

PT-BR requirements: child-friendly Brazilian vocabulary, avoid European Portuguese forms; localize note names (Dó, Ré, Mi, Fá, Sol, Lá, Si) in labels while retaining canonical MIDI/pitch IDs. EN-GB uses C, D, E, F, G, A, B. Numbering and beat units remain numeric; date/time are local. Accessible labels and captions require full translations.

Fallback: if locale dictionary is incomplete, use en-GB and show language consistently; never produce untranslated mixed sentence. Validate parity for every key and all class dialogue.
