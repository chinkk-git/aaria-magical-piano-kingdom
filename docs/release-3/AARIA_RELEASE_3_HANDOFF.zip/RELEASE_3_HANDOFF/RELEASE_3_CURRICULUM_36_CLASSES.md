# Curriculum index — 36 complete structured lessons

Machine-readable lesson definitions are in `RELEASE_3_LESSON_CONTENT/`. Every lesson includes original playable MIDI-pitch events, pitch labels, event lengths, hand/fingering suggestions, three exercises, bilingual coach dialogue and objectives, a complete 15-minute schedule, detection eligibility, feedback rules, remediation, accessibility and completion logic. The written lesson files are the content source of truth; no copyrighted melody is used.

| Level | IDs | Focus sequence |
|---|---|---|
| Basic | B01–B12 | keyboard map; Middle C; fingers/posture; C-D-E; pulse/rest; five-finger; first reading; left hand; phrases; durations; melody; mini performance |
| Medium | M01–M12 | hand roles; hands together; C scale; intervals; dynamics; subdivisions; triads; accompaniment; reading; articulation; phrasing; complete two-hand piece |
| Advanced | A01–A12 | G/F scales; signatures; arpeggios; independent hands; syncopation; progressions; register shifts; sight-reading; expression; chunking; interpretation; recital |

## Music-data notation
`midi` uses MIDI note numbers (A4=69); `pitch` is scientific pitch name; time is in quarter-note beats from lesson start; 4/4 bar numbers are one-based; `durationBeats` is positive; tempo in BPM is quarter-note BPM. A rest is represented as an explicit interval between event offsets, not an invented note. `hand` and `finger` are ergonomic suggestions that must be adapted for comfort.

## Important validation limit
These are original pedagogical drafts and structured source sequences prepared for worker implementation. A qualified piano educator should review hand assignment, score engraving, developmental progression and exact playable comfort before production. JSON structural validation is not expert music pedagogy approval.
