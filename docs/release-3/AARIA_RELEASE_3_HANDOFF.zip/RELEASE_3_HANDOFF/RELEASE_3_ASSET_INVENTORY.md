# Visual asset and production inventory

Visual Workstream B owns final art/layout. This package intentionally includes no claimed approved coach artwork.

| Asset family | Production specification | Pending owner/design input |
|---|---|---|
| Coach concepts | 2–3 concept directions; original; layered source; transparent PNG/WebP; welcome/demo/think/encourage/celebrate/retry states | character identity, selected direction, expressions |
| Academy scene | scalable SVG/WEBP, low-motion and static fallback | final composition and palette extension |
| Class icons | 36 reusable icon tokens grouped by concept; avoid color-only level indicators | illustration style |
| Controls | focus, pressed, disabled, listening, connected, manual, error states; 44px minimum | final shapes |
| Audio | use existing synthesis adapter after repository contract audit; no recordings included | coach voice choice (optional) |

Manifest fields: `path`, `format`, `dimensions`, `role`, `variant`, `localeNeutral`, `source/author`, `license`, `sha256`, `estimatedBytes`, `offlineGroup`. Optimize for mobile; keep core shell lightweight; optional coach animation loaded on demand. All third-party inputs require provenance/license review.

Until art exists, use CSS token placeholders, semantic icon labels, `prefers-reduced-motion`, and neutral geometric silhouettes. Never use generated concepts as production screenshot evidence or state owner approval.
