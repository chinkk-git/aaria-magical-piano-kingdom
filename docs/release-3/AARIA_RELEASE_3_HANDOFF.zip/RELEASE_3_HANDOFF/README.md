# Release 3 — Aaria’s Magical Piano Academy handoff

This is a planning and content package for a separate Release 3 implementation branch. It is not an implementation claim or a production release. Main-source audit was anchored to `c1d88ceb60ec05e78976ab9082dbddd794661344` (merged PR #24) and the open Issue #25 hotfix tracker as observed on 2026-11-19. Check GitHub before implementation because the hotfix branch may advance.

## Contents

- Fourteen implementation handoff documents named `RELEASE_3_*.md`.
- Thirty-six bilingual JSON lessons in `RELEASE_3_LESSON_CONTENT/` (B01–B12, M01–M12, A01–A12).
- JSON Schema, sample fixture, and curriculum validator under `schemas/`, `fixtures/`, and `tests/`.
- Visual placeholders only: layout/artwork remain a separate owner workstream.

## Validate

Run `python3 tests/validate_curriculum.py` from this directory. The validator checks file count, IDs, level counts, bilingual required fields, schedule totals, event sequence integrity, unlocked prerequisite arrays, and supported input modes. Passing it validates package consistency only; it does not verify pedagogy, device compatibility, audio accuracy, or app integration.

## Safe implementation boundary

Build Release 3 only after rebasing against the latest approved main after Issue #25. Avoid changing Piano Hero, `index.html`, `sw.js`, song library, Add New Song/OMR, PWA update flow, or persistent storage in parallel with Issue #25. Create new modules under a feature namespace and integrate behind a non-destructive route/feature flag. Do not merge or deploy without owner approval.
