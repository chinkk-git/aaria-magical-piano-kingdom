import json, pathlib, re, sys
root=pathlib.Path(__file__).resolve().parents[1]; files=sorted(p for p in (root/"RELEASE_3_LESSON_CONTENT").glob("*.json") if re.fullmatch(r"[BMA](0[1-9]|1[0-2])",p.stem)); assert len(files)==36, f"expected 36, got {len(files)}"
ids=set(); counts={"basic":0,"medium":0,"advanced":0}
for p in files:
 d=json.loads(p.read_text()); assert d["lessonId"]==p.stem; assert d["lessonId"] not in ids; ids.add(d["lessonId"]); counts[d["level"]]+=1
 assert not d["prerequisites"]; assert set(d["title"])=={"en-GB","pt-BR"}; assert set(d["objective"])=={"en-GB","pt-BR"}
 assert sum(d["scheduleMinutes"].values())==15; assert len(d["exercises"])>=3; assert len(d["demonstration"]["audioEvents"])>=4
 ev=d["demonstration"]["audioEvents"]; assert all(e["durationBeats"]>0 and isinstance(e["midi"],int) and e["pitch"] for e in ev); assert [e["onsetBeat"] for e in ev]==sorted(e["onsetBeat"] for e in ev)
 assert set(d["inputPolicy"]["supportedModes"])=={"manual","on-screen","microphone","midi"}; assert len(d["lessonStructure"])==5
 assert all("en" in x["script"] and "pt-BR" in x["script"] for x in d["lessonStructure"])
assert counts=={"basic":12,"medium":12,"advanced":12}, counts
print(f"PASS: {len(files)} lessons; counts={counts}; all prerequisite arrays empty; schedule and input checks passed")
