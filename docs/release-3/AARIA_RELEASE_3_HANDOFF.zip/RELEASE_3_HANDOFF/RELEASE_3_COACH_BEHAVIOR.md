# Deterministic coach behavior

## State machine
`idle → class-selected → warm-up → explain → demo → guided-practice → application → reflection → complete`; any active state may enter `paused`, `mode-setup`, or `recoverable-error`. `mode-setup` returns to prior state or manual fallback. `complete` is revisitable; no gating edges exist between lessons. `skip` advances stage with completion marked as skipped, not mastered.

## Behavior rules
- Intro names one objective and says she may pause or leave. Demo highlights the exact event currently sounding; count-in is off by default.
- Guided prompt asks for one action, waits for child-controlled Ready in manual mode; no fictional listening, score, or progress.
- Detected correct note: brief positive cue. Likely missed/wrong: name the target note and invite retry once, then offer continue/slow/chunk. Uncertain signal: say listening was unclear and suppress score. Never call a child careless or wrong.
- Independent mode reduces narration and retains controls, labels, and help. Voice synthesis is optional; captions/text are equivalent.
- Adaptation uses explicit child choices and locally observed patterns only. Start with repeat/slow/shorter chunk suggestions. Never raise difficulty automatically or lock content.
- Time pacing is advisory: the learner may pause indefinitely, shorten, repeat, or finish. No countdown during practice.
- Celebration is low-key and non-comparative; no streak loss, pressure, or surprise sound. Respect reduced-motion and silent mode.

## Localization keys
All prompts are supplied per lesson in `en-GB` and `pt-BR`. Shared UI keys and accessibility announcements are specified in `RELEASE_3_LOCALIZATION.md`; no runtime machine translation.
