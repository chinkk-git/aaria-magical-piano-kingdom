# Data models and safe persistence

## LessonDefinition
Canonical format is each lesson JSON; schema is `schemas/lesson.schema.json`. Lesson content has stable ID, bilingual strings, 15-min schedule, original event timeline, exercises, input policies and completion criteria. Prerequisites are an empty array by product rule.

## Session / learner records
- `AcademyProfile {schemaVersion, locale, lastMode, textScale, reducedMotion, voiceEnabled}`. No account/name/birthdate.
- `LessonSession {sessionId, lessonId, startedAt, updatedAt, currentStage, currentExerciseId?, beatOffset, completionState, source}`. `source` says manual, on-screen, MIDI, microphone.
- `CompletionRecord {lessonId, completedAt, completionType: learner|guided, sectionsSkipped[], selfReflection?, contentVersion}`.
- `ObservationRecord {lessonId, exerciseId, source, metric, numerator, denominator, confidence, calibrationId, createdAt}`. No raw audio. Separate note and rhythm metrics.
- `Achievement {achievementId, earnedAt, basis: participation|self-reported|measured}`; no streak or leaderboard.

## Storage boundary
Create new IndexedDB database/store namespace (recommend `aaria-piano-academy`, version 1; object stores `profiles`, `sessions`, `completions`, `observations`, `achievements`). Do not modify `aaria-piano-library` v2 or song keys. Final namespace is subject to confirming app storage usage during implementation.

Writes are transactional and idempotent by stable record ID. Handle quota/storage denial with in-memory session and clear recovery notice; never remove songs or OMR cache. Export only on explicit adult-controlled action; JSON export excludes device IDs and raw audio. Import validates schema and merges by ID, never overwrites library stores.

## Migration
Additive only; `schemaVersion` and migration functions are deterministic. Backup academy store before each migration. If validation fails, leave previous version intact and continue classes in session memory. Rollback does not delete stores.
