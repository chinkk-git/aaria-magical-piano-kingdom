# Worker handoff — Aaria’s Magical Piano Academy R3

## Start instruction
Repository `chinkk-git/aaria-magical-piano-kingdom`. Read this package and the latest Issue #11/#25 state. Create a dedicated R3 branch only after confirming Issue #25’s head and merge status; base on latest approved main, never on a stale planning snapshot. Preserve the Issue #25 branch and its files.

## First action
Post acknowledgment on the R3 planning PR/issue when created. Re-run a baseline audit; note changed source contracts. No Release 3 code edits may touch hotfix files until that work is merged and owner-approved.

## Implementation order
Follow `RELEASE_3_IMPLEMENTATION_BACKLOG.md` R3-01 through R3-14. Treat every lesson JSON as original content draft ready for implementation but requiring educator review prior to release. Treat all visual slots as placeholders pending separate Workstream B owner design.

## Mandatory invariants
- Physical manual mode is default and fully usable without keyboard connection.
- All 36 classes are directly available, no skill evaluation gates.
- Mic and MIDI adapters both implemented; activation optional; truthful unsupported fallback.
- No unmeasured score, no raw audio retention/transmission.
- No destructive storage migration; preserve Piano Hero, Classic, songs, saved arrangements, OMR and SW updates.
- EN-GB/PT-BR; zero-cost; no external AI or cloud requirement.
- No merge/deploy without owner approval.

## Reporting template
`Stage / branch+SHA / artifacts / completed IDs / tests passed-failed-not run / device evidence / data-preservation evidence / blockers / next action / owner decision`. Never label simulation as hardware test.

## Visual integration contract
Use semantic slots and tokens in `RELEASE_3_COMPONENT_CONTRACTS.md`. Build behavior before final art. Later replace placeholder compositions while keeping route, input state, stage transitions, note data and accessibility semantics. Do not invent owner approval.
